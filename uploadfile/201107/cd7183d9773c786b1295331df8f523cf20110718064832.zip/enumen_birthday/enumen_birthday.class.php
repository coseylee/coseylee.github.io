<?php
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class plugin_enumen_birthday
{
	var $month = 0;
	var $day = 0;
	var $userlist = array();
	var $nums = 0;
	
	function plugin_enumen_birthday()
	{
		$this -> month = intval(date('n'));
		$this -> day = intval(date('j'));
		
		@include DISCUZ_ROOT.'./data/cache/cache_enumen_birthday.php';
		if ($cache['month'] == $this -> month && $cache['day'] == $this -> day)
		{
			$this -> userlist = $cache['userlist'];
			$this -> nums = $cache['nums'];
		}
		else
		{
			global $_G;
			$sql = "SELECT b.`username`,b.`groupid` FROM ".DB::table('common_member_profile')." a LEFT JOIN ".DB::table('common_member')." b USING(uid) WHERE a.`birthmonth` = '{$this -> month}' AND a.`birthday` = '{$this -> day}'";
			$query = DB::query($sql);
			while($row = DB::fetch($query))
			{
				if ($row['groupid'] <= 3)
				{
					$row['img'] = $_G['cache']['onlinelist'][$row['groupid']];
				}
				else
				{
					$row['img'] = $_G['cache']['onlinelist'][0];
				}
				unset($row['groupid']);
				$this -> userlist[] = $row;
			}
			$this -> nums = count($this -> userlist);
			
			$cache = array(
				'month' => $this -> month,
				'day' => $this -> day,
				'nums' => $this -> nums,
				'userlist' => $this -> userlist,
				);
			@include_once libfile('function_cache', 'function');
			writetocache('enumen_birthday', '$cache = '.var_export($cache, true));
		}
	}
}

class plugin_enumen_birthday_forum extends plugin_enumen_birthday
{
	function index_enumen_birthday_nums()
	{
		return "(��{$this -> nums}��)";
	}
	
	function index_enumen_birthday()
	{
		$userlist = $this -> userlist;
		include template('enumen_birthday:show');
		return $return;
	}
}