<?php

/*
 * Created on 2010
 * Link for job@phpyun.com
 * This PHPYun.Rencai System Powered by PHPYun.com
 */
class action {

	public $db; //����mysql
	public $tp; //����template
	public $def; //�������ݿ�ǰ׺
	private $md = 'PP#JOB0#!@'; //�����ַ�����Ҫ�޸�

	/*��ʼ��*/
	function __construct($db, $tp, $def) {
		$this->db = $db;
		$this->tp = $tp;
		$this->def = $def;
	}

	/* ͷ���Ĵ����͵���*/
	function ACT_tpfun($arr) {
		sort($arr); //��������
		$this->tp->set_var($this->GET_web_con());
		foreach ($arr as $val) {
			$this->tp->set_file($val);
			$this->tp->n();
		}
	}
	/* �Ų��Ĵ����͵�����ʾ*/
	function ACT_footer($value, $foot = 'footer', $debug = '') {
		if(is_array($value)){ //�����������ѭ������
			foreach ($value as $val) {
			$this->tp->set_file($val);
			$this->tp->n();
			}
		}else{ //�������������ֱ��ʹ��
			$this->tp->set_file($value);
			$this->tp->n();
		}
		if (!empty ($foot)) {
			$this->tp->set_file($foot);
			$this->tp->n();
		}
		$this->tp->p($value);
		if (!empty ($debug))
			$this->tp->inc_list(); //����
	}

	/**
	 * ��Ϣ��ʾ��
	 * url:��ת��ַ msg:��ʾ��Ϣ st:0��̾1�ɹ�2ʧ�� tm:��תʱ��*/
	function ACT_msg($url, $msg = "�����ѳɹ���", $st = 1, $tm = 3, $sysloginhtml = '') {
		$this->tp->set_var(array (
			"job_arr_msg" => $msg,
			"job_arr_url" => $url,
			"job_arr_st" => $st,
			"job_arr_tm" => $tm,
			"job_arr_sysloginhtml" => $sysloginhtml));
		$this->tp->set_file('msg');
		$this->tp->p();
		exit ();
	}

	/**
	* ͨ�õ�����ѯ$tablename,$where = 1, $select="*"
	*/
	function DB_select_once($tablename, $where = 1, $select = "*") {
		 $SQL = "SELECT $select FROM " . $this->def . $tablename . " WHERE $where limit 1";
		$query = $this->db->query($SQL);
		return $this->db->fetch_array($query);
	}

		/**
	* ͨ��������ѯ$tablename,$where = 1, $select="*"
	*/
	function DB_select_num($tablename, $where = 1, $select = "*") {
		$SQL = "SELECT $select FROM " . $this->def . $tablename . " WHERE $where";
		$query = $this->db->query($SQL);
		return $this->db->db_num_rows($query);
	}

	/**
	* ͨ��query��ѯ $tablename,$where = 1, $select="*"
	*/
	function DB_select_query($tablename, $where = 1, $select = "*") {
	    $SQL = "SELECT $select FROM " . $this->def . $tablename . " WHERE $where";
		$query=$this->db->query($SQL);
		 return $query;
	}

	/**
	* ͨ��all��ѯ $tablename,$where = 1, $select="*"
	*/
	function DB_select_all($tablename, $where = 1, $select = "*") {
		$SQL = "SELECT $select FROM `" . $this->def . $tablename . "` WHERE $where";
		$query=$this->db->query($SQL);
		 while($row=$this->db->fetch_array($query)){$row_return[]=$row;}
		 return $row_return;
	}

		/**
	* ͨ��all��ѯ˫�� $tablename1,$tablename2, $where = 1, $select = "*"
	*/
	function DB_select_alls($tablename1,$tablename2, $where = 1, $select = "*") {
		$SQL = "SELECT $select FROM " . $this->def . $tablename1. " as a," . $this->def . $tablename2 . " as b WHERE $where";
		$query=$this->db->query($SQL);
		 while($row=$this->db->fetch_array($query)){$row_return[]=$row;}
		 return $row_return;
	}

	/**
	 * ������������ $tablename, $value
	 */
	function DB_insert_once($tablename, $value) {
		$SQL = "INSERT INTO `" . $this->def . $tablename . "` SET $value";
		$this->db->query($SQL);
		return $this->db->insert_id($SQL);
	}

	/**
	 * ���� $tablename, $value, $where = 1
	 */
	function DB_update_all($tablename, $value, $where = 1) {
		$SQL = "UPDATE `" . $this->def . $tablename . "` SET $value WHERE $where";
		return $this->db->query($SQL);
	}

	/**
	 * ɾ�� $tablename, $value, $where = 1
	 */
	function DB_delete_all($tablename, $where, $limit = 'limit 1') {
		 $SQL = "DELETE FROM `" . $this->def . $tablename . "` WHERE $where $limit";
		return $this->db->query($SQL);
	}
	//======================�û���½Ȩ�޿���======================================

	/*�û�Ȩ��*/
	function GET_user_shell($uid, $shell) {
		$query = $this->db->query("SELECT * FROM `" . $this->def . "userid` WHERE `uid`='$uid' limit 1");
		$us = is_array($row = $this->db->fetch_array($query));
		$shell = $us ? $shell == md5($row[username] . $row[password] . $this->md) : FALSE;
		return $shell ? $row : NULL;
	} //end shell

	/*����û�Ȩ��*/
	function GET_user_shell_check($uid, $shell, $m_id = 9, $url = 'login.php') {
		if ($row = $this->get_user_shell($uid, $shell)) {
			if ($row[usertype] <= $m_id) {
				return $row;
			} else {
				echo "����Ȩ�޲�����";
				exit ();
			} //end m_id
		} else {
			$this->ACT_msg($url, '���ȵ�½��');
		}
	} //end shell

	/**
	 * �û���½
	 */
	function Get_user_login($username, $password, $urlture = 'usermanage.php', $urlfalse = 'login.php') {
		$username = str_replace(" ", "", $username);
		// ��UC��ȡ�û�
		list($uid) = uc_user_login($username, $password);
		if ($uid > 0)
		{
			$query = $this->db->query("SELECT * FROM `" . $this->def . "userid` WHERE `username`='$username' limit 1");
			$us = is_array($row = $this->db->fetch_array($query));
			$ps = $us ? md5($password) == $row[password] : FALSE;
			if ($us)
			{
				if ($ps)
				{
					SetCookie("uid", $row[uid], time() + 80000, "/");
					SetCookie("username", $row[username], time() + 80000, "/");
					SetCookie("shell", md5($row[username] . $row[password] . $this->md), time() + 80000, "/");
					$this->DB_update_all("userid", "`date_login`='" . mktime() . "',`iponline`='" . $this->db->fun_ip_get() . "'", "`uid`='$row[uid]'");
					if ($urlture)
					{
						$this->ACT_msg($urlture, '��½�ɹ���', $st = 1, $tm = 3, uc_user_synlogin($uid));
					}
				}
				else
				{
					// �û������뱾ϵͳ��һ�£��ڱ�ϵͳִ�����á�
					$new_password = md5($password);
					if ($this->db->query("UPDATE `" . $this->def . "userid` SET `password` = '{$new_password}' WHERE `username`='$username'"))
					{
						$this->ACT_msg("login.php", '����ͬ���ɹ�! �����µ�¼��');
					}
					else
					{
						$this->ACT_msg("login.php", '����ͬ��ʧ��! ');
					}
				}
			}
			else
			{
				$query = $this->db->query("SELECT * FROM `" . $this->def . "comid` WHERE `username`='$username' limit 1");
				$us = is_array($row = $this->db->fetch_array($query));
				if ($us)
				{
					$this->ACT_msg("logins.php", '������ҵ�û��뵽��ҵ��¼�ڵ�¼!');
				}
				else
				{
					// �����ʺ�Ҫ�ж��û��Ƿ�����ҵ�û�
					$_SESSION['waitUserName'] = $username;
					$this->ACT_msg("active.php", '�뼤���ʺ�!');
				}
			}
		}
		elseif ($uid == -1)
		{
			$this->ACT_msg($urlfalse, '�û������ڣ����߱�ɾ��');
		}
		elseif ($uid == -2)
		{
			$this->ACT_msg($urlfalse, '�Բ����������');
		}
		else
		{
			$this->ACT_msg($urlfalse, '��¼ʧ��');
		}
	}
	/**
	 * �û��˳���½
	 */
	public function Get_user_out($url = 'login.php') {
		SetCookie("uid", "", time() - 80000, "/");
		SetCookie("shell", "", time() - 80000, "/");
		$this->ACT_msg($url, '�˳��ɹ���', $st = 1, $tm = 3, uc_user_synlogout());
	}

	//======================��ҵ��½Ȩ�޿���======================================

	/*�û�Ȩ��*/
	function GET_com_shell($uid, $shell) {
		$query = $this->db->query("SELECT * FROM `" . $this->def . "comid` WHERE `uid`='$uid' limit 1");
		$us = is_array($row = $this->db->fetch_array($query));
		$shell = $us ? $shell == md5($row[username] . $row[password] . $this->md) : FALSE;
		return $shell ? $row : NULL;
	} //end shell

	/*����û�Ȩ��*/
	function GET_com_shell_check($uid, $shell, $m_id = 9, $url = 'logins.php') {
		if ($row = $this->get_com_shell($uid, $shell)) {
			if ($row[usertype] <= $m_id) {
				return $row;
			} else {
				echo "����Ȩ�޲�����";
				exit ();
			} //end m_id
		} else {
			$this->ACT_msg($url, '���ȵ�½��');
		}
	} //end shell

	function com_type($comuid){
      $com=$this->DB_select_once("comid","`uid`='$comuid'");
      $time=($com[vip_time]-mktime())/86400;
      if($com[usertype]==2 && $time>=120 && $time<365){
        $type=3;
      }elseif($com[usertype]==3 && $time>365){
       $type=4;
      }elseif($time>=365){
         $type=4;
      }else{
      	$type=$com[usertype];
      }
     return $type;
	}

	/**
	 * �û���½
	 */
	function Get_com_login($username, $password, $urlture = 'commanage.php', $urlfalse = 'logins.php') {
		$username = str_replace(" ", "", $username);
		// ��UC��ȡ�û�
		list($uid) = uc_user_login($username, $password);
		if ($uid > 0)
		{
			$query = $this->db->query("SELECT * FROM `" . $this->def . "comid` WHERE `username`='$username' limit 1");
			$us = is_array($row = $this->db->fetch_array($query));
			$ps = $us ? md5($password) == $row[password] : FALSE;
			//������

			if($us)
			{
				if ($ps)
				{
					if($row[usertype]==0)
					{
						$this->ACT_msg($urlfalse, '����δͨ����ˣ�');
					}
					else
					{
						SetCookie("cuid", $row[uid], time() + 80000, "/");
						SetCookie("cusername", $row[username], time() + 80000, "/");
						SetCookie("cshell", md5($row[username] . $row[password] . $this->md), time() + 80000, "/");
						if($row[usertype]>1)
						{
							if($row[vip_time]<mktime())
							{
								$where="`vip_time`='0',`usertype`='1',";
							}
							else
							{
								$where="`usertype`=".$this->com_type($row[uid]).",";
							}
						}
						else
						{
							$where=null;
						}

						$this->DB_update_all("comid", "$where `date_login`='" . mktime() . "',`iponline`='" . $this->db->fun_ip_get() . "'", "`uid`='$row[uid]'");
						if ($urlture)
						{
							$this->ACT_msg($urlture, '��½�ɹ���', $st = 1, $tm = 5, uc_user_synlogin($uid));
						}
					}
				}
				else
				{
					// �û������뱾ϵͳ��һ�£��ڱ�ϵͳִ�����á�
					$new_password = md5($password);
					if ($this->db->query("UPDATE `" . $this->def . "comid` SET `password` = '{$new_password}' WHERE `username`='$username'"))
					{
						$this->ACT_msg("logins.php", '����ͬ���ɹ�! �����µ�¼��');
					}
					else
					{
						$this->ACT_msg("logins.php", '����ͬ��ʧ��! ');
					}
				}
			}
			else
			{
				$query = $this->db->query("SELECT * FROM `" . $this->def . "userid` WHERE `username`='$username' limit 1");
				$us = is_array($row = $this->db->fetch_array($query));
				if ($us)
				{
					$this->ACT_msg("login.php", '���Ǹ����û��뵽���˵�¼�ڵ�¼!');
				}
				else
				{
					$_SESSION['waitUserName'] = $username;
					$this->ACT_msg("active.php", '�뼤���ʺ�!');
				}
			}
		}
		elseif ($uid == -1)
		{
			$this->ACT_msg($urlfalse, '�û������ڣ����߱�ɾ��');
		}
		elseif ($uid == -2)
		{
			$this->ACT_msg($urlfalse, '�Բ����������');
		}
		else
		{
			$this->ACT_msg($urlfalse, '��¼ʧ��');
		}
	}
	/**
	 * �û��˳���½
	 */
	public function Get_com_out($url = 'logins.php') {
		SetCookie("cuid", "", time() - 80000, "/");
		SetCookie("cshell", "", time() - 80000, "/");
		//$this->ACT_msg($url, '�˳��ɹ���');
		$this->ACT_msg($url, '�˳��ɹ���', $st = 1, $tm = 5, uc_user_synlogout());
	}



	//==========================���ö���===============================

	/**
	 * ϵͳ��������
	 */
	function GET_web_con() {
		$query = $this->DB_select_all("admin_config");
		foreach($query as $v){ $con_row[$v[0]]=$v[1];}
		return $con_row;
	}

	/**
	 * ��ȡ��������
	 */
	function news_class($table,$where){
       $query = $this->DB_select_all($table,$where);
       if($query[0][0]){
	    foreach($query as $v){$newsclass.=$v[0].",";}
       }
       return $newsclass;
    }

  function advertise($where,$num){
   $query=$this->DB_select_all("advertise","`position`='$where' and `edate`>='".mktime()."' order by id desc limit $num");
   return $query;
	}

function user_complete($num){
	    switch($num){
      	case 0:
      	$numresume=$numresume+0;
      	break;
      	case 1:
      	$numresume=$numresume+5;
      	break;
      	case 2:
      	$numresume=$numresume+10;
      	break;
      	default:
      	$numresume=$numresume+12.5;
      	break;
      }
      return $numresume;
}
function complete($eid,$useruid){
	$user_resume = $this->DB_select_once("user_resume", "`eid`='$eid' and `uid`='$useruid'");
       if($user_resume[expect]==1){
       	$numresume=10;
       }
$numresume=$numresume+$this->user_complete($user_resume[skill]);
$numresume=$numresume+$this->user_complete($user_resume[work]);
$numresume=$numresume+$this->user_complete($user_resume[project]);
$numresume=$numresume+$this->user_complete($user_resume[edu]);
$numresume=$numresume+$this->user_complete($user_resume[training]);
$numresume=$numresume+$this->user_complete($user_resume[cert]);
$numresume=$numresume+$this->user_complete($user_resume[other]);
return $numresume;
}

function GET_web_url(){
	$url=explode("/",$_SERVER["REQUEST_URI"]);
	if($url[2]=="news"){
      $value= "../";
	}elseif($url[1]=="news"){
    $value= "../";
}else{
     $value="./";
	}
	return $value;
}



function GET_web_key($key=1){
	if($key!=1){
    $config=$this->GET_web_con();
    $value=$config[$key];
	}
return $value;
}

function GET_web_des($con){
	    return substr(str_replace(array("\r","\n"),array(" "," "),strip_tags($con)),0,200);
}

function GET_web_news($id,$type=1){
	if($type==2){
      $where="`id`>'$id'";
	}else{
      $where="`id`<'$id' order by id desc";
	}

     $con=$this->DB_select_once("news_base",$where,"`id`,`title`");
return $con;
}


} //end class
?>