<?php
/*
 * UCenter �û�����
 */
include_once ("global.php");

$obj = new action($db, $tp, DEF_DATA);
if (!isset($_SESSION['waitUserName']))
{
	$obj->ACT_msg("index.php", "�Բ����㲻��ִ�д˲�����");
	exit;
}
//====================��������========================\\

if (isset ($_POST[actsub]))
{
	
	$username = isset($_POST['username']) ? trim($_POST['username']) : '';
	$spassword = isset($_POST['spassword']) ? trim($_POST['spassword']) : '';
	$regtype = isset($_POST['regtype']) ? intval($_POST['regtype']) : '';
	
	if (md5($_POST[authcode]) === $_SESSION[authcode] && $_SESSION['waitUserName'] == $username && !empty($spassword))
	{
		$uc_uid = uc_user_login($username, $spassword);
		if ($uc_uid > 0)
		{
			list(,,$email) = uc_get_user($username);
			$into_user = "`username`='{$username}'";
			$into_user .= ",`password`='" . md5($spassword) . "'";
			$into_user .= ",`email`='{$email}'";
			$into_user .= ",`date_reg`='" . mktime() . "'";
			$into_user .= ",`usertype`='0'";
			if ($regtype == 1) // �����û�
			{
				if ($last_uid=$obj->DB_insert_once("userid", $into_user))
				{
					$obj->DB_insert_once("resume","uid='$last_uid',name=''");
					unset($_SESSION['waitUserName']);
					//$obj->GET_user_login($_POST[username], $_POST[spassword],false);
					$msgemail="<script src='js/xajax.inc.js'></script>";
					$msgemail2="<script>login_msg('user','".$email."','".$username."','".$spassword."');</script>";
					$obj->ACT_msg("usermanage.php", "����ɹ���������ת����Ĺ������棡", $st = 1, $tm = 3, uc_user_synlogin($uc_uid));
				}
			}
			elseif ($regtype == 0) // ��ҵ�û�
			{
				if ($last_uid=$obj->DB_insert_once("comid", $into_user))
				{
					$obj->DB_insert_once("company","uid='$last_uid',name=''");
					unset($_SESSION['waitUserName']);
					$msgemail="<script src='js/xajax.inc.js'></script>";
					$msgemail2="<script>login_msg('user','".$email."','".$username."','".$spassword."');</script>";
					//$obj->GET_com_login($_POST[username], $_POST[spassword],false);
					$obj->ACT_msg("logins.php", "����ɹ�����ȴ�������ˣ�");
				}
			}
			else
			{
				$obj->ACT_msg("active.php", "������Ϣ����ȷ��");
			}
		}
		else
		{
			$obj->ACT_msg("active.php", "�������");
		}
	}
	else
	{
		$obj->ACT_msg("active.php", "������Ϣ����ȷ��");
	}

}

//====================ģ������========================\\
$username = $_SESSION['waitUserName'];
$obj->tp->clear();
$obj->ACT_tpfun(array ('header'));
$obj->ACT_footer(array('active','left'));

?>