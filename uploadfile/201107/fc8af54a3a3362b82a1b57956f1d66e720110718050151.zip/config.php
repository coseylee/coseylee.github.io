<?php
//mysql database address
define('DB_HOST','');
//mysql database user
define('DB_USER','');
//database password
define('DB_PASSWD','');
//database name
define('DB_NAME','');
//database prefix
define('DB_PREFIX','db_');
//auth key
define('AUTH_KEY','D(V@$ZlU!7gZGC#EzXO%m603xRQAvf(rda0f7a299aad5d94aecdcee20abeb06b');
//cookie name
define('AUTH_COOKIE_NAME','EM_AUTHCOOKIE_ZmWYC2y46Wc5sdIYSHnLs5iiIhb7Mqu1');
// SAE Storage Domain
define('STORAGE_DOMAIN', 'upload');
// SAE Storage URL
define('STORAGE_URL', 'http://'.$_SERVER['HTTP_APPNAME'].'-'.STORAGE_DOMAIN.'.stor.sinaapp.com/');