<?php
/**
 * 新浪云平台数据库引擎
 *
 * @copyright (c) Emlog All Rights Reserved
 * $Id: mysql.php 1796 2010-10-31 04:26:06Z emloog $
 */

class MySql
{
	private $queryCount = 0;
	private $sae_mysql = null;
	private $result;
	private static $instance = null;

	private function __construct()
	{
		if (class_exists('SaeMysql'))
		{
			$this -> sae_mysql = new SaeMysql();
			$this -> sae_mysql -> setCharset('utf8');
		}
		else
		{
			emMsg('SaeMysql Only For Sina App Engine.');
			exit;
		}
	}

	public static function getInstance()
	{
		if (self::$instance == null)
		{
			self::$instance = new MySql();
		}
		return self::$instance;
	}

	public function close()
	{
		return $this -> sae_mysql -> closeDb();
	}

	public function query($sql)
	{
		$this -> result = $this -> sae_mysql -> runSql($sql);
		$this -> queryCount++;
		if (!$this->result)
		{
			emMsg('SQL语句执行错误：'.$sql.' <br />'.$this -> sae_mysql -> error());
		}
		else
		{
			return $this -> result;
		}
	}

	public function fetch_array($results, $type = MYSQLI_ASSOC)
	{
		return $results -> fetch_array($type);
	}

	public function once_fetch_array($sql)
	{
		$this -> result = $this -> query($sql);
		return $this -> fetch_array($this -> result);
	}

	public function fetch_row($results)
	{
		return $results -> fetch_array(MYSQLI_NUM);
	}

	public function num_rows($results)
	{
		return mysqli_num_rows($results);
	}

	public function num_fields($results)
	{
		return $results -> field_count;
	}
	
	public function insert_id()
	{
		return $this -> sae_mysql -> lastId();
	}

	public function geterror()
	{
		return $this -> sae_mysql -> error();
	}

	public function affected_rows()
	{
		return $this -> sae_mysql -> affectedRows();;
	}

	public function getMysqlVersion()
	{
		return 'SAE MySQL';
	}

	public function getQueryCount()
	{
		return $this -> queryCount;
	}
}
