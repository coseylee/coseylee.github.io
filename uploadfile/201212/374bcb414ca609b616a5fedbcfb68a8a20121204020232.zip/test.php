<?php
ob_start();
for($i = 1; $i <= 30; $i++) {
	echo str_repeat(' ', 4096);
	echo '<script>parent.document.getElementById(\'show\').innerHTML = parent.document.getElementById(\'show\').innerHTML + '.$i.' + "<br/>"</script><br/>';
	ob_flush();
	flush();
	if (1)
	{
		usleep(500000);
	}
	else
	{
		sleep(2);
	}
}
exit;