<?php
define('USER','admin');
define('PASSWORD','e10adc3949ba59abbe56e057f20f883e');

header("Content-type: text/html; charset=gbk");

// ��¼����

if ($_GET['action'] == 'login')
{      
        Login();
}

// �˳�����

if ($_GET['action'] == 'logout')
{
        LoginOut();
}

// ���Ӳ���
if ($_GET['action'] == 'add')
{
        Add();
}

// ɾ�����Բ���

if ($_GET['action'] == 'delete')
{
        Delete();
}

// �ظ�����

if ($_GET['action'] == 'reply')
{
        Reply();
}

// ɾ���ظ�����

if ($_GET['action'] == 'deletereply')
{
        DeleteReply();
}

function connectMysql() // �������ݿ�
{
        $conn = mysql_connect('localhost','root','phpnow');
        mysql_select_db('member',$conn);
        mysql_query('SET NAMES gbk');
        return $conn;
}

function isLogin() // �ж��Ƿ��¼
{
        if ($_COOKIE['user'] == USER && $_COOKIE['password'] == PASSWORD)
        {
                return true;
        }
        else
        {
                return false;
        }
}

function noLogin()
{
        echo '��û�е�¼����<a href="?action=login">��¼</a>�������';
}
function Login() // ��¼�ű�
{
        if ($_GET['check'] == 'ok')
        {
                if ($_POST['user'] == USER && md5($_POST['password']) == PASSWORD)
                {
                        setcookie('user',USER,time()+3600);
                        setcookie('password',PASSWORD,time()+3600);
                        header('location:index.php');
                }
                else
                {
                        echo '<script>window.location.href="?action=login&notice=false";</script>';
                }
        }
        else
        {
                $form = <<< EOT
                                <table border="0" cellpadding="5" cellspacing="1" >
                                <form action="?action=login&check=ok" method="post">
                                <tr><td></td><td align="center">��¼</td></tr>
                                <tr><td>�û�����</td><td><input type="text" name="user" style="width:100px"></td></tr>
                                <tr><td>���룺</td><td><input type="password" name="password" style="width:100px"></td></tr>
                                <tr><td></td><td><input type="submit" value="��¼">&nbsp;&nbsp;<a href="">����</a><td></tr>
                                </form>
                                </table>
EOT;
                if ($_GET['notice'] == 'false')
                {
                        echo '�û������������<br/><br/>';
                }
                echo $form;
        }
}

function LoginOut()  // �˳��ű�
{
        setcookie('user','',time()-pow(60,60));
        setcookie('password','',time()-pow(60,60));
        echo '<script>window.location.href="";</script>';
}

function Add()  // �������Խű�
{
        $user = isset($_POST['user']) ? htmlspecialchars($_POST['user']) : '';
        $title = isset($_POST['title']) ? htmlspecialchars($_POST['title']) : '';
        $content = isset($_POST['content']) ? htmlspecialchars($_POST['content']) : '';

        if (!empty($user) && !empty($title) && !empty($content))
        {
                $conn = connectMysql();                
                $sql = 'INSERT INTO `message` (`id`,`user`,`title`,`content`,`lastdate`) VALUES ("","'.$user.'","'.$title.'","'.$content.'",now())';
                if (mysql_query($sql,$conn))
                {
                        $ok = 'addok';
                }
                else
                {
                        $ok = 'addfalse';
                }
                mysql_close($conn);
        }
        echo '<script>window.location.href="index.php?ok='.$ok.'";</script>';
}

function Delete() // ɾ�����Խű�
{
        if (isLogin())
        {
                $id = intval($_GET['id']);
                
                $conn = connectMysql();
                $sql = 'DELETE FROM `message` WHERE `id` = '.$id;
                if (mysql_query($sql,$conn))
                {
                        echo '<script>window.location.href="index.php?ok=deleteok";</script>';
                }
                mysql_close($conn);
        }
        else
        {
                noLogin();
        }
}

function Reply() // �ظ����Խű�
{
        if (isLogin())
        {
                $conn = connectMysql();
                if ($_GET['check'] == 'ok')
                {
                        $id = isset($_GET['id']) ? intval($_GET['id']) : '';
                        $reply = isset($_POST['reply']) ? htmlspecialchars($_POST['reply']) : '';
                        
                        if (!empty($id) && !empty($reply))
                        {
                                $sql = 'UPDATE `message` SET `reply` ="'.$reply.'" WHERE `id` = '.$id;
                                if (mysql_query($sql,$conn))
                                {
                                        echo '<script>window.location.href="index.php?ok=replyok";</script>';
                                }
                        }
                }
                else
                {
                        $id = isset($_GET['id']) ? intval($_GET['id']) : '';
                        $result = mysql_query('SELECT * FROM `message` WHERE `id` = '.$id,$conn);
                        $row = mysql_fetch_array($result);
                        
                        $form = <<< EOT
                                        <table border="0" cellpadding="5" cellspacing="1" >
                                        <form action="index.php?action=reply&id={$id}&check=ok" method="post">
                                        <tr><td align="center">��[{$row['user']}]��[{$row['title']}]�����ظ�:</td></tr>
                                        <tr><td>ԭ��д��:{$row['content']}</td></tr>
                                        <tr><td>�ظ����ݣ�</td></tr>
                                        <tr><td><textarea rows="5" cols="30" name="reply" >{$row['reply']}</textarea></td></tr>
                                        <tr><td><input type="submit" value="�ظ�">&nbsp;&nbsp;<a href="">����</a><td></tr>
                                        </form>
                                        </table>
EOT;
                        echo $form;
                }
                mysql_close($conn);
        }
        else
        {
                noLogin();
        }
}

function DeleteReply()
{
        $conn = connectMysql();
        $id = intval($_GET['id']);
        $sql = 'UPDATE `message` SET `reply` = "" WHERE `id` ='.$id;
        if (mysql_query($sql,$conn));
        {
                echo '<script>window.location.href="index.php?ok=deletereplyok";</script>';
        }
}
?>