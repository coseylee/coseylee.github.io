<?php

class isDir
{
        private $dirname;
        private $basename;
        private $dirtype = 'Dir';
        private $dirsize;
        private $ctime;
        private $offon = true;
        
        function __construct($dir)
        {             
                $this -> dirname = $dir;
                $this -> ctime = date('Y-m-d h:i:s',filectime($dir));
                $this -> basename = substr($dir,strrpos($dir,'/')+1);
                $this -> dirsize = $this -> toFileSize($dir);
        }
        
        function getFileType()
        {
                return $this -> dirtype;
        }
        
        function toFileSize($dir)
        {
                if ($this -> offon)
                {
                        $fp = opendir($dir);
                        $sum = 0;
                        while (($file = readdir($fp)) !== false)
                        {
                                $subfile = $dir.'/'.$file;
                                if ($file != '.' && $file != '..')
                                {
                                        if (is_file($subfile))
                                        {
                                                $sum += filesize($subfile);
                                        }
                                        else
                                        {
                                                $sum += $this -> toFileSize($subfile);
                                        }
                                }
                        }
                        closedir($fp);
                        return $sum;
                }
                else
                {
                        return 0;
                }
        }
        
        function getFileSize()
        {
                $size = $this -> dirsize;
                if ($size < pow(1024,1))
                {
                        return $size.' Byte';
                }
                elseif ($size < pow(1024,2))
                {
                        return round($size/pow(1024,1),2).' KB';
                }
                elseif ($size < pow(1024,3))
                {
                        return round($size/pow(1024,2),2).' MB';
                }
                else
                {
                        return round($size/pow(1024,3),2).' GB';
                }
        }
        
        function getBaseName()
        {
                return $this -> basename;
        }
        
        function getFileName()
        {
                return $this -> dirname;
        }
                
        function getCtime()
        {
                return $this -> ctime;
        }
        
        function rename($newname)
        {
                rename($this -> dirname,substr($this -> dirname,0,strrpos($this -> dirname,'/')+1).$newname);
        }
}

?>