<?php
$time = explode(' ',microtime());
$startime = $time[0] + $time[1];
unset($time);
include 'isFile.class.php';
include 'showDir.class.php';
include 'isDir.class.php';

if (isset($_GET['dir']) && !empty($_GET['dir']))
{
        $showDir = new showDir(stripslashes($_GET['dir']));
}
else
{
        $showDir = new showDir();
}
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 TRANSITIONAL//EN">
<html>
<head><title><?php echo $showDir -> getPath() ?></title>
<meta content="text/html; charset=gbk" http-equiv=content-type>
<style>
div {
        padding-left:10px;
        margin-bottom:10px;
}
td {
        padding-left:5px;
}
a {
        text-decoration:none;
}
.class td{
        text-align:center;
}
</style>
</head>
<body>
<div style="line-height:30px;background-color:#E0E0E0">
�ϼ�Ŀ¼Ϊ��<a href="index.php?dir=<? echo $showDir -> getPrePath() ?>" >
<? echo $showDir -> getPrePath() ?></a>&nbsp;&nbsp;
��ǰĿ¼Ϊ��<a href="index.php?dir=<? echo $showDir -> getPath() ?>" >
<? echo $showDir -> getPath() ?></a><br />
��ʼĿ¼Ϊ��<a href="index.php?dir=<? echo dirname($_SERVER['SCRIPT_FILENAME']) ?>" ><? echo str_replace('\\','/',dirname($_SERVER['SCRIPT_FILENAME']))?></a>
</div>

<div style="line-height:30px;background-color:#F0F0F0" >
<? $showDir -> getFiles() ?></div>

<div style="line-height:30px;background-color:#E0E0E0"><?php echo $showDir -> getFileNum().'&nbsp;&nbsp;'.date('Y-m-d h:i:s',time()); ?></div>
<?php
$time = explode(' ',microtime());
$endtime = $time[0] + $time[1];
echo '�򵥵��ļ��鿴 {'.round($endtime - $startime,8).'} Seconds ��дʱ�䣺2010-06-09 Coseylee Blog.Zinedo.Com';
unset($time,$endtime,$startime);
?></body>
</html>