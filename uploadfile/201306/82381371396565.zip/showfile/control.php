<?php
include 'isDir.class.php';
include 'isFile.class.php';

$filename = isset($_GET['filename']) ? $_GET['filename'] : '';
$basename = isset($_GET['basename']) ? $_GET['basename'] : '';
$action = isset($_GET['action']) ? $_GET['action'] : '';

unset($_GET['filename'],$_GET['basename'],$_GET['action']);

if ($filename == '' || $basename == '' || $action == '')
{
        echo '�����Ƿ�';
        exit;
}

if (is_dir($filename))
{
        if ($action == 'delete')
        {
                 echo 'Ŀ¼�޷�ɾ��';
                 exit;
        }
        
        $obj = new isDir($filename);
}
else
{
        $obj = new isFile($filename);
}

if ($action == 'rename')
{
        if (isset($_GET['newname']) && !empty($_GET['newname']) && $_GET['check'] == 'yes')
        {
                $obj -> rename($_GET['newname']);
                unset($_GET['newname'],$_GET['check']);
                echo '<a href="index.php">����</a>';
        }
        else
        {
                echo '<form action="control.php" method="get">';
                echo '<input type="hidden" name="action" value="rename">';
                echo '<input type="hidden" name="filename" value="'.$filename.'">';
                echo '<input type="hidden" name="basename" value="'.$basename.'">';
                echo '<input type="hidden" name="check" value="yes">';
                echo $filename.'<br /><br />';
                echo '���������ļ� '.$basename.'&nbsp;<a href="index.php">ȡ��</a><br /><br />';
                echo '���������ļ�����<input type="text" name="newname">';
                echo '<input type="submit" value="������">';
                echo '</form>';
        
        }
}

if ($action == 'delete')
{
        if ($_GET['check'] == 'yes')
        {
                $obj -> delete();
                unset($_GET['newname'],$_GET['check']);
                echo '<a href="index.php">����</a>';
        }
        else
        {
                echo '<form action="control.php" method="get">';
                echo '<input type="hidden" name="action" value="delete">';
                echo '<input type="hidden" name="filename" value="'.$filename.'">';
                echo '<input type="hidden" name="basename" value="'.$basename.'">';
                echo '<input type="hidden" name="check" value="yes">';
                echo $filename.'<br /><br />';
                echo '��ɾ���ļ� '.$basename.'&nbsp;<a href="index.php">ȡ��</a><br /><br />';
                echo '<input type="submit" value="ɾ��">';
                echo '</form>';
        
        }
}
?>
