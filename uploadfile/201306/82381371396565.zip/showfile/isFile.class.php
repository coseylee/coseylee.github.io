<?php

class isFile
{
        private $filename;
        private $basename;
        private $filetype = 'File';
        private $filesize;
        private $ctime;
        
        function __construct($file)
        {
                $this -> filename = $file;
                $this -> basename = basename($file);
                $this -> filesize = filesize($file);
                $this -> ctime = date('Y-m-d h:i:s',filectime($file));
        }
        
        
        function getFileType()
        {
                return $this -> filetype;
        }
        
        function getFileSize()
        {
                $size = $this -> filesize;
                if ($size < pow(1024,1))
                {
                        return $size.' Byte';
                }
                elseif ($size < pow(1024,2))
                {
                        return round($size/pow(1024,1),2).' KB';
                }
                elseif ($size < pow(1024,3))
                {
                        return round($size/pow(1024,2),2).' MB';
                }
                else
                {
                        return round($size/pow(1024,3),2).' GB';
                }
        }
        
        function getBaseName()
        {
                return $this -> basename;
        }
        
        function getFileName()
        {
                return $this -> filename;
        }
        
        function getCtime()
        {
                return $this -> ctime;
        }
        
        function rename($newname)
        {
                rename($this -> filename,dirname($this -> filename).'/'.$newname);
        }
        
        function delete()
        {
                unlink($this -> filename);
        }
        
}

?>