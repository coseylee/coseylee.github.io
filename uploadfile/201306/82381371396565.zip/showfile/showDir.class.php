<?php

class showDir
{
        private $path;
        private $prepath;
        private $dirnum;
        private $filenum;
        
        function __construct($path = '.')
        {
                if ($path == '.')
                {
                        $path = dirname($_SERVER['SCRIPT_FILENAME']);
                }
                
                $path = str_replace('\\','/',$path);
                
                if ($path[strlen($path)-1] == '/')
                {
                        $path = substr($path,0,strlen($path)-1);
                }
                
                $this -> path = $path;
                // echo 'path '.$this -> path.'<br />';
                $this -> prepath = substr($path,0,strrpos($path,'/'));
                // echo 'prepath '.$this -> prepath;
        }
        
        function getFiles()
        {
                $this -> filenum = $this -> dirnum = 0;
                $fp = opendir($this -> path);
                echo '<table width="98%">';
                echo '<tr class="class"><td>�ļ�����</td><td>�ļ�����</td><td>�ļ���С</td><td>����ʱ��</td><td>����</td></tr>';
                $i = 0;
                while (($file = readdir($fp)) !== false)
                {
                        $subfile = $this -> path.'/'.$file;
                        if ($file != '.' && $file != '..')
                        {
                                if ($i%2 == 0)
                                {
                                        $color = 'bgcolor="#D0D0D0"';
                                }
                                else
                                {
                                        $color = '';
                                }
                                
                                if (is_dir($subfile))
                                {
                                        $tmp = new isDir($subfile);
                                        $this -> dirnum++;
                                        $dirin = '<a href="control.php?action=rename&basename='.$tmp ->getBaseName().'&filename='.$tmp -> getFileName().'">������</a>&nbsp;<a href="index.php?dir='.$tmp -> getFileName().'">����</a>';
                                }
                                else
                                {
                                       $tmp = new isFile($subfile);
                                       $this -> filenum++;
                                       $dirin = '<a href="control.php?action=rename&basename='.$tmp ->getBaseName().'&filename='.$tmp -> getFileName().'">������</a>&nbsp;<a href="control.php?action=delete&basename='.$tmp ->getBaseName().'&filename='.$tmp -> getFileName().'">ɾ��</a>';
                                }
                                echo '<tr '.$color.'><td>'.$tmp -> getFileType().'</td><td>'.$tmp -> getBaseName().'</td><td>'.$tmp -> getFileSize().'</td><td align="center">&nbsp;'.$tmp -> getCtime().'</td><td>&nbsp;'.$dirin.'</td></tr>'."\n";
                                        
                        }
                        $i++;
                }
                closedir($fp);
                unset($fp,$i,$file,$subfile,$tmp,$color,$dirin);
                echo '</table>';
        }
        
        function getPrePath()
        {
                return $this -> prepath;
        }
        
        function getPath()
        {
                return $this -> path;
        }
        
        function getFileNum()
        {
                $sum = $this -> filenum + $this -> dirnum;
                return '��ǰĿ¼�¹����ļ���'.$sum.'���������ļ���'.$this -> filenum.'����Ŀ¼��'.$this -> dirnum.'�������з�����СΪ��'.round(disk_total_space($this -> path)/pow(1024,2),2).' MB';
        }

}

//$dir = new showDir('');
//$dir -> getFiles();
?>